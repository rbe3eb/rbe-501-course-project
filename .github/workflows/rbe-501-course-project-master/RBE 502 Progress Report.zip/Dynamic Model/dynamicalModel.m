function [M, C, G] = dynamicalModel(T)
    syms l1 l2 l3 l4 l5 l6 l7 ...
        m1 m2 m3 m4 m5 m6 m7 g ...
        q1 q2 q3 q4 q5 q6 q7 ...
        dq1 dq2 dq3 dq4 dq5 dq6 dq7 ...
        ddq1 ddq2 ddq3 ddq4 ddq5 ddq6 ddqq7 real;
    
    tau = cell(6,1);
    I = cell(6,1);
    R = cell(6,1);
    g = 9.81 * [0; 0; 1];
    q = [q1, q2, q3, q4, q5, q6]';
    dq = [dq1, dq2, dq3, dq4, dq5, dq6]';
    
    % Mass of the link (grams)
    mass = [583.341, 1167.569, 593.781, 367.799, 367.799, ...
        621.039];
    
    % Length of the link (mm)
    length = [159.758, 492.517, 248.258, 135.263, 135.263, ...
        107.345];
    
    % Coordinates of the center of mass (mm)
    rc = [[10.879; -0.01; 226.184], [-24.195; -0.002; 480.492], ...
        [16.852; 0.002; 760.264], [-4.545; 0.015; 956.344], ...
        [24.045; 0.015; 1036.656], [9.74; 1.494; 1158.87]];
    
    % Moment of Inertia at Center of Mass (g*mm^2)
	Ixx = [1.902E+06, 2.870E+07, 3.912E+06, 7.368E+05, ...
        7.368E+05, 6.692E+05];
	Ixy = [2.418E+04, 9.402, -7.653, 17.362, -8.345, ...
        8.345, 52.016];
	Ixz = [-2.331E+05, -43.188, 1.489E+05, 1.510E+05, ...
        1.510E+05, -292.982];
	Iyx = [9.402, -7.653, 17.362, -8.345, ...
        8.345, 52.016];
	Iyy = [1.778E+06, 2.819E+07, 3.727E+06, 7.492E+05, ...
        7.492E+05, 1.005E+06]; 
	Iyz = [-98.997, -867.047, 334.219, 63.799, ...
        -63.799, -2.288E+04];
	Izx = [-2.331E+05, -43.188, 1.489E+05, 1.510E+05, ...
        1.510E+05, -292.982]; 
	Izy = [-98.997, -867.047, 334.219, 63.799, ...
        -63.799, -2.288E+04];
	Izz = [7.121E+05, 8.923E+05, 4.649E+05, 3.035E+05, ...
        3.035E+05, 7.318E+05];
    

    for i=1:6
        % Form inertia tensor
        I{i} = [Ixx(i) Ixy(i) Ixz(i)
                Iyx(i) Iyy(i) Iyz(i)
                Izx(i) Izy(i) Izz(i)];
        % Collect rotation matrices
        R{i} = T{i}(1:3,1:3);
    end
    
    r = computeCOM(T,rc);
    Jcom = jacobianCOM(T,r);
    K = computeKE(Jcom,R,I,mass);
    P = computePE(mass,g,r);
    L = K - P;
    
    % Compute torque
    for n=1:6
        tau{n} = lagrange(L,q(n),dq(n));
    end
    
    m = cell(6,1);
    g = cell(6,1);
    for n=1:6
        m{n} = inertiaMatrix(tau{n});
        g{n} = gravity(tau{n});
    end
    M = [m{1}; m{2}; m{3}; m{4}; m{5}; m{6}];
    G = [g{1}; g{2}; g{3}; g{4}; g{5}; g{6}];
    
    for n=1:6
       c{n} = coriolis(tau{n}, M(n,:), G(n,1)); 
    end
    C = [c{1}; c{2}; c{3}; c{4}; c{5}; c{6}];
end