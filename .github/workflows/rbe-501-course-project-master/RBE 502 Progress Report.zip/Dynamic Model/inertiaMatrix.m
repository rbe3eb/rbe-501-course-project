function m = inertiaMatrix(tau)
    syms ddq1 ddq2 ddq3 ddq4 ddq5 ddq6
    m1 = (tau - subs(tau, ddq1, 0)) / ddq1;
    m2 = (tau - subs(tau, ddq2, 0)) / ddq2;
    m3 = (tau - subs(tau, ddq3, 0)) / ddq3;
    m4 = (tau - subs(tau, ddq4, 0)) / ddq4;
    m5 = (tau - subs(tau, ddq5, 0)) / ddq5;
    m6 = (tau - subs(tau, ddq6, 0)) / ddq6;
    m = [m1 m2 m3 m4 m5 m6];
end