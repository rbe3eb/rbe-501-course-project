function g = gravity(tau)
    syms dq1 dq2 dq3 dq4 dq5 dq6 ...
        ddq1 ddq2 ddq3 ddq4 ddq5 ddq6 real;
    g = subs(tau, [dq1, dq2, dq3, dq4, dq5, dq6, ddq1, ddq2, ddq3, ...
        ddq4, ddq5, ddq6], [0 0 0 0 0 0 0 0 0 0 0 0]);
    g = simplify(g);
end
