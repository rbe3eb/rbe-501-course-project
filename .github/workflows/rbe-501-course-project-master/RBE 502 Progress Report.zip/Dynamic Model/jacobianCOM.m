function Jcom = jacobianCOM(T,r)
    syms q1 q2 q3 q4 q5 q6 real
    jv{1} = simplify(jacobian(r(1:3,1),[q1]));
    jv{2} = simplify(jacobian(r(1:3,2),[q1,q2]));
    jv{3} = simplify(jacobian(r(1:3,3),[q1,q2,q3]));
    jv{4} = simplify(jacobian(r(1:3,4),[q1,q2,q3,q4]));
    jv{5} = simplify(jacobian(r(1:3,5),[q1,q2,q3,q4,q5]));
    jv{6} = simplify(jacobian(r(1:3,6),[q1,q2,q3,q4,q5,q6]));
    
    jw{1} = [0; 0; 1];
    jw{2} = simplify([([0 0 1])', T{1}(1:3,3)]);
    jw{3} = simplify([([0 0 1])', T{1}(1:3,3), T{2}(1:3,3)]);
    jw{4} = simplify([([0 0 1])', T{1}(1:3,3), T{2}(1:3,3), T{3}(1:3,3)]);
    jw{5} = simplify([([0 0 1])', T{1}(1:3,3), T{2}(1:3,3), T{3}(1:3,3), ...
        T{4}(1:3,4)]);
    jw{6} = [([0 0 1])', T{1}(1:3,3), T{2}(1:3,3), T{3}(1:3,3), ...
        T{4}(1:3,4), T{5}(1:3,3)];
    
    Jcom = {[jv{1}; jw{1}], [jv{2}; jw{2}], [jv{3}; jw{3}], ...
        [jv{4}; jw{4}], [jv{5}; jw{5}], [jv{6}; jw{6}]};
end