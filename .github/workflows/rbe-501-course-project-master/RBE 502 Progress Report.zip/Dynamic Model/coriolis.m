function c = coriolis(tau, m, g)
    syms ddq1 ddq2 ddq3 ddq4 ddq5 ddq6 real
    c = tau - (m * [ddq1 ddq2 ddq3 ddq4 ddq5 ddq6].' + g);
    c = (c);
end