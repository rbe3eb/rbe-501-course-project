function r = computeCOM(T,rc)
    cnt = size(T,1);
    r = sym([]);
    r(1:4,1) = [rc(1:3,1); 1];
    for i=2:cnt
       r(1:4,i) = T{i-1} * [rc(1:3,i); 1];
    end
end