% Obtain transformation matrix from DH parameters
function [A] = DH(alpha, a, d, theta)
    a11 = cos(theta);
    a12 = -1*sin(theta)*cos(alpha);
    a13 = sin(theta)*sin(alpha);
    a14 = a*cos(theta);
    a21 = sin(theta);
    a22 = cos(theta)*cos(alpha);
    a23 = -1*cos(theta)*sin(alpha);
    a24 = a*sin(theta);
    a32 = sin(alpha);
    a33 = cos(alpha);
    a34 = d;
    
    A = [a11, a12, a13, a14;
         a21, a22, a23, a24;
          0,  a32, a33, a34;
          0,   0,   0,   1];
end