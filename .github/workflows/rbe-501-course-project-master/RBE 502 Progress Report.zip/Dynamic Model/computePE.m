function P = computePE(m,g,r)
    cnt = size(r,2);
    p = cell(cnt,1);
    for i=1:6
        p{i} = m(i)*g'*r(1:3,i);
    end
    P = p{1} + p{2} + p{3} + p{4} + p{5} + p{6};
end