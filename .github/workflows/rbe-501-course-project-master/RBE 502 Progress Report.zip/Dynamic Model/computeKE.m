% Compute the kinetic energy
function K = computeKE(Jcom,R,I,m)
     syms dq1 dq2 dq3 dq4 dq5 dq6 real
%     dq = [dq1, dq2, dq3, dq4, dq5, dq6];
%     d = cell(6,1);
%     for i=1:6
%         d{i} = (m(i)*Jcom{i}(1:3,i)'*Jcom{i}(1:3,i)) ...
%             + (Jcom{i}(4:6,i)'*R{i}*I{i}*R{i}'*(Jcom{i}(4:6,i)));
%     end
%     D = d{1} + d{2} + d{3} + d{4} + d{5} + d{6};
%     K = (1/2)*dq'*D*dq;
    
    v1 = Jcom{1}(1:3,:) * dq1;
    v2 = Jcom{2}(1:3,:) * [dq1; dq2];
    v3 = Jcom{3}(1:3,:) * [dq1; dq2; dq3];
    v4 = Jcom{4}(1:3,:) * [dq1; dq2; dq3; dq4];
    v5 = Jcom{5}(1:3,:) * [dq1; dq2; dq3; dq4; dq5];
    v6 = Jcom{6}(1:3,:) * [dq1; dq2; dq3; dq4; dq5; dq6];
    K1 = 0.5 * m(1) * (v1.' * v1);
    K2 = 0.5 * m(2) * (v2.' * v2);
    K3 = 0.5 * m(3) * (v3.' * v3);
    K4 = 0.5 * m(4) * (v4.' * v4);
    K5 = 0.5 * m(5) * (v5.' * v5);
    K6 = 0.5 * m(6) * (v6.' * v6);
    K = K1 + K2 + K3 + K4 + K5 + K6;
end